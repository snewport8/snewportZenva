
const Direction = {
RIGHT: 'RIGHT',
LEFT: 'LEFT',
UP: 'UP',
DOWN: 'DOWN',



};

class PlayerContainer extends Phaser.GameObjects.Container {
    constructor(scene, x, y, key, frame) {
        super(scene, x, y);
        this.scene = scene;
        this.velocity = 100; //player velocity when moving
        this.currentDirection = Direction.RIGHT;
        this.playerAttacking = false;
        this.flipX = true;
        this.swordHit = false;


            //set size on the container
            this.setSize(32, 32);
            //enable physics
            this.scene.physics.world.enable(this);
             //collide world bounds
              this.body.setCollideWorldBounds(true);
              // add player container to existing scene
              this.scene.add.existing(this);
              //camera to follow player container
              this.scene.cameras.main.startFollow(this);

              //create player and add to container
              this.player = new Player(this.scene, 0, 0, key, frame);
              this.add(this.player);
    
              //create weapon object
              this.weapon = this.scene.add.image(20, 0, 'items', 4);
              this.scene.add.existing(this.weapon);
              this.weapon.setScale(0.75);
              this.scene.physics.world.enable(this.weapon);
              this.add(this.weapon);
              this.weapon.alpha = 0;

    }

    update(cursors) {

        this.body.setVelocity(0);
    
        if (cursors.left.isDown) {
            this.body.setVelocityX(-this.velocity);
            this.currentDirection = Direction.LEFT;
            this.weapon.setPosition(-20, 0);
            this.player.flipX = false;
        } else if (cursors.right.isDown) {
            this.body.setVelocityX(this.velocity);
            this.currentDirection = Direction.RIGHT;
            this.weapon.setPosition(20, 0);
            this.player.flipX = true;
    
        }
    
        if (cursors.up.isDown) {
            this.body.setVelocityY(-this.velocity);
            this.currentDirection = Direction.UP;
            this.weapon.setPosition(0, -25);
        } else if (cursors.down.isDown) {
            this.body.setVelocityY(this.velocity);
            this.currentDirection = Direction.DOWN;
            this.weapon.setPosition(0, 25);
     
        }
    if (Phaser.Input.Keyboard.JustDown (cursors.space) && !this.playerAttacking){
            this.weapon.alpha = 1;
            this.playerAttacking = true;
            this.scene.time.delayedCall(300, () => {this.weapon.alpha= 0;
            this.playerAttacking = false;
           this.swordHit = false;
            }, [], this);
    }
        if (this.playerAttacking) {
            if (this.weapon.flipX) {
                this.weapon.angle -= 10;
            } else {
                this.weapon.angle += 10;

            }

        } else {
            if (this.currentDirection === Direction.DOWN) {
                this.weapon.setAngle(-270);
            } else if (this.currentDirection === Direction.UP) {
                this.weapon.setAngle(-90);
            } else {
                this.weapon.setAngle(0);
            }

                this.weapon.flipX = false;
                if (this.currentDirection === Direction.LEFT) {
                    this.weapon.flipX = true;
                }
        }
            }
        }